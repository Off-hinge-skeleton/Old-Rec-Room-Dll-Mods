﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KittyRec
{
    abstract class BasePatch
    {
        //public abstract void Patch(HarmonyLib.Harmony harmony);
    }
}
