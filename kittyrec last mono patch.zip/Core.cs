﻿using AmplitudeAnalytics;
using MelonLoader;
using UnityEngine;
using Valve.VR.InteractionSystem;
using HarmonyLib;
using System.Diagnostics;
using Discord;
using DiscordStatus;
using System.Reflection;
using RecNet;
using System.Text;
using KittyRec.UI;
using TMPro;
using KittyRec.Patches;
using AmplitudeMiniJSON;

#if DEBUG
using KittyRec.KR_Debug;
#endif


[assembly: MelonInfo(typeof(KittyRec.Core), "KittyRec", "1.0.0", "EggRecRoom", null)]
[assembly: MelonGame("Against Gravity", "Rec Room")]

namespace KittyRec
{
    internal class Core : MelonMod
    {
        public bool Disabled = false;
        public const long AppId = 1397260905586102423;
        public Discord.Discord discordClient;
        public ActivityManager activityManager;
        private bool gameClosing;

        public void DebugLog(string msg)
        {
#if DEBUG
            MelonLogger.Msg(msg);
#endif
        }
        public static void _DebugLog(string msg)
        {
#if DEBUG
            MelonLogger.Msg(msg);
#endif
        }

        public void DiscordLoopThread()
        {
            for (; ; )
            {
                if (gameClosing)
                    break;

                discordClient.RunCallbacks();
                UpdateActivity();
                Thread.Sleep(200);
            }
        }

        public override void OnEarlyInitializeMelon()
        {
            MelonLogger.Msg(Environment.GetDebugText());
#if RELEASE
            if (LACHJMJGMPK.PPEPNDPKGHN != "20181206_EA")
            {
                MelonLogger.Error("Wrong Rec Room version");
                HarmonyInstance.UnpatchSelf();
                Disabled = true;
                Application.Quit();
            }
#endif
            Process.GetProcesses();


            DiscordLibraryLoader.LoadLibrary();
            InitializeDiscord();
            UpdateActivity();
            new Thread(DiscordLoopThread).Start();
        }

        public override void OnApplicationQuit()
        {
            gameClosing = true;
        }

        public override void OnSceneWasLoaded(int buildIndex, string sceneName)
        {
            UpdateActivity(sceneName);
            //var sceneManager = GameObject.FindObjectOfType<RecRoomSceneManager>();
            //if (sceneManager != null)
            //{

            //}
        }

        private void DiscordLogHandler(LogLevel level, string message)
        {
#if DEBUG
            switch (level)
            {
                case LogLevel.Info:
                case LogLevel.Debug:
                    LoggerInstance.Msg(message);
                    break;

                case LogLevel.Warn:
                    LoggerInstance.Warning(message);
                    break;
                
                case LogLevel.Error:
                    LoggerInstance.Error(message);
                    break;
            }
#endif
        }

        public void InitializeDiscord()
        {
            discordClient = new Discord.Discord(AppId, (ulong)CreateFlags.NoRequireDiscord);
            discordClient.SetLogHook(LogLevel.Error, DiscordLogHandler);

            activityManager = discordClient.GetActivityManager();
        }

        public override void OnInitializeMelon()
        {
            //var harmony = new HarmonyLib.Harmony("com.tabbycluster.kittyrec");
            HarmonyInstance.PatchAll();

            AmplitudeAnalyticsClient.IsEnabled = false;
            LoggerInstance.Msg("Initialized.");
        }
        public static void UniversalPostfix(ref bool __result)
        {
            __result = !__result;
        }

        public override void OnLateInitializeMelon()
        {
            if (Disabled) { Application.Quit(); return; }
            GameObject go = new GameObject("DevOverlay");
#if DEBUG
            go.AddComponent<KittyRec.KR_Debug.ButtonUi>();
            go.AddComponent<KittyRec.KR_Debug.ItemSpawner>();
#endif
            go.AddComponent<PerformanceUi>();
            GameObject.DontDestroyOnLoad(go);

            FieldInfo field = AccessTools.Field(typeof(MBCEJNEHLNI), "AOGFPFHECKJ");
            var myResult = field.GetValue(null) as AGRoomRuntimeConfig;


            JsonUtility.FromJsonOverwrite(Encoding.UTF8.GetString(Resource.AGRoomRuntime), myResult);
        }

        static FieldInfo richPresenceStringField = typeof(ScenePresenceSettings).GetField("richPresenceString", BindingFlags.NonPublic | BindingFlags.Instance);
        public void UpdateActivity(string sceneName = null)
        {
            if (sceneName == null)
            {
                try
                {
                    var sc = UnityEngine.SceneManagement.SceneManager.GetActiveScene();
                    sceneName = sc.name;
                }
                catch { }
                
            }
            var activity = new Activity
            {
                Name = $"KittyRec",
                Type = ActivityType.Playing,
                Details = $"",

            };
            if (sceneName != null)
            {
                switch (sceneName)
                {
                    case "ProfileSelection":
                        activity.Details = $"In the login screen";
                        break;
                    case "splash_screen":
                        activity.Details = $"In the splash screen";
                        break;
                }
            }

            if (EMBELFFPLDJ.GJOJFGMLOEA != null)
            {
                if (EMBELFFPLDJ.GJOJFGMLOEA.JCIHIGFMDFH != "^dormroom")
                {
                    activity.Details = $"Hanging out in {EMBELFFPLDJ.GJOJFGMLOEA.JCIHIGFMDFH}";
                    if (EMBELFFPLDJ.GJOJFGMLOEA.JBMABOKCEAE)
                    {
                        activity.Details = $"Playing {EMBELFFPLDJ.GJOJFGMLOEA.JCIHIGFMDFH}";

                    }

                    activity.Party = new ActivityParty
                    {
                        Id = "",
                        Size = new PartySize
                        {
                            CurrentSize = DAHGDBPKKAJ.NABEKNPODNO.Length,
                            MaxSize = (ushort)EMBELFFPLDJ.GJOJFGMLOEA.GDBEFGNIDLL
                        }
                    };
                }
                
            }

            activity.Instance = true;
            activity.Assets.LargeText = activity.Name;


            activityManager.UpdateActivity(activity, ResultHandler);
        }

        public void ResultHandler(Result result)
        {

        }

        public override void OnSceneWasInitialized(int buildIndex, string sceneName)
        {
            if (Disabled) { Application.Quit(); return; }
            base.OnSceneWasInitialized(buildIndex, sceneName);
            //UpdateGameRequirement();



            foreach (UnityEngine.UI.Text obj in Resources.FindObjectsOfTypeAll<UnityEngine.UI.Text>())
            {
                obj.text = TextReplace.Replace(obj.text);
            }
            foreach (TMP_Text obj in Resources.FindObjectsOfTypeAll<TMP_Text>())
            {
                obj.text = TextReplace.Replace(obj.text);
            }
            foreach (TextMesh obj in Resources.FindObjectsOfTypeAll<TextMesh>())
            {
                obj.text = TextReplace.Replace(obj.text);
            }

            if (sceneName == "RecRoyale_Frontier") {
                GameMode[] gameModes = UnityEngine.Object.FindObjectsOfType<GameMode>();

                if (gameModes == null || gameModes.Length == 0) return;

                FieldInfo field = typeof(GameMode).GetField("gameStartSettings", BindingFlags.NonPublic | BindingFlags.Instance);

                if (field != null)
                {
                    foreach (GameMode gameMode in gameModes)
                    {
                        var settings = (ModeGameStartSettings)field.GetValue(gameMode);

                        settings.GameStartTeamRequirement = NDBELFKJBCN.TWO_TEAMS_ONE_PLAYER;

                        field.SetValue(gameMode, settings);
                    }
                }
            }


            //AntiCheat
            if (sceneName != "ProfileSelection" && sceneName != "splash_screen")
            {
                if (!string.IsNullOrEmpty(BHOEHJMOOIP.JOIHPPIKJFM))
                {
                    Dictionary<string, object> processes = [];
                    foreach (Process process in Process.GetProcesses())
                    {
                        if (processes.ContainsKey(process.ProcessName))
                        {
                            continue;
                        }

                        /*string filePath = "Unknown";
                        string startTime = "Unknown";

                        try
                        {
                            filePath = process.MainModule?.FileName ?? "Unknown";
                            startTime = process.StartTime.ToString("yyyy-MM-dd HH:mm:ss");
                        }
                        catch
                        {
                        }*/

                        processes.Add(process.ProcessName, new
                        {
                            process.Id,
                            /*Path = filePath,
                            Started = startTime*/
                        });
                    }
                    EILONPGCMFP.KMGONIPCODP("api/PlayerReporting/v1/checkProcesses", LICOIPFEBMF.ONLMKJFEJIA(processes), false);
                }
            }
            
            
        }
    }
}