﻿using Google.Protobuf.Collections;
using KittyRec;
using MelonLoader;
using System;
using System.IO;
using System.Reflection;
using System.Resources;
using System.Runtime.InteropServices;

namespace DiscordStatus
{
    public static class DiscordLibraryLoader
    {
        public static bool Loaded { get; private set; }

        public const string LibDestinationPath = "UserData/KittyRec/discord_game_sdk.dll";

        public static void LoadLibrary()
        {
            if (Loaded)
                return;

            if (!File.Exists(LibDestinationPath))
            {
                Directory.CreateDirectory(Path.GetDirectoryName(LibDestinationPath));
                var data = Resource.DiscordGameSDK;
                File.WriteAllBytes(LibDestinationPath, data);
            }

            if (LoadLibrary(LibDestinationPath) == IntPtr.Zero)
                throw new DllNotFoundException($"Could not load the Discord SDK library from '{LibDestinationPath}'.");

            MelonLogger.Msg("Discord Library loaded.");
            Loaded = true;
        }

        [DllImport("kernel32.dll")]
        private static extern IntPtr LoadLibrary(string path);
    }
}
