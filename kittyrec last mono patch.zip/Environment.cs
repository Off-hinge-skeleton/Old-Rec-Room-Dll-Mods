﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
public static class Environment
{
    public enum EnvironmentType
    {
        Prod = 0,
        Dev = 1,
        BVT = 2,
        Test = 3
    }

    public static readonly EnvironmentType type = EnvironmentType.Dev;

    //public static readonly string nameserver = "kittyrec.tabbycluster.net";
    public static readonly string nameserver = "ns-kittyrec.tabbycluster.net";


    public static string GetDebugText()
    {
        return $"""
        RecRoom Version: {LACHJMJGMPK.PPEPNDPKGHN}
        RecRoom Built At: {new DateTime(LACHJMJGMPK.IIGEOGFLCIP):M/d/yyyy H:mm:ss}

        KittyRec Environment: {type}
        KittyRec Git Branch: {ThisAssembly.Git.Branch}
        KittyRec Git Commit: {ThisAssembly.Git.Commit}
        KittyRec Name Server: {nameserver}
        """;
    }

}