﻿using KittyRec.KR_Debug;
using System.Reflection;
using UnityEngine;
using UnityEngine.Events;
using System;
using System.Collections.Generic;
using System.Linq;

namespace KittyRec.KR_Debug
{
    public class ButtonUi : MonoBehaviour
    {//ai did this i suck at ui
        public static bool showMenu = true;

        private Vector2 scrollPos;
        private readonly List<DebugButtonData> buttons = new();

        // Define the modifier key for the combos (e.g., LeftControl)
        private const KeyCode ModifierKey = KeyCode.LeftControl;

        // A list of keys to automatically assign to buttons in order
        private readonly KeyCode[] availableKeys =
        [
            KeyCode.Alpha1, KeyCode.Alpha2, KeyCode.Alpha3, KeyCode.Alpha4, KeyCode.Alpha5,
            KeyCode.Alpha6, KeyCode.Alpha7, KeyCode.Alpha8, KeyCode.Alpha9, KeyCode.Alpha0,
            KeyCode.Minus, KeyCode.Equals,
            KeyCode.F2, KeyCode.F3, KeyCode.F4, KeyCode.F5, KeyCode.F6, KeyCode.F7, KeyCode.F8
        ];

        private class DebugButtonData
        {
            public string Name;
            public string Tooltip;
            public bool RequiresMaster;
            public UnityAction Call;
            public KeyCode Hotkey; // Added to store the assigned key
        }

        public static List<Type> GetAllDebugButtons()
        {
#if DEBUG
            return AppDomain.CurrentDomain.GetAssemblies()
                .SelectMany(a =>
                {
                    try
                    {
                        return a.GetTypes();
                    }
                    catch (ReflectionTypeLoadException e)
                    {
                        return e.Types.Where(t => t != null)!;
                    }
                })
                .Where(t =>
                    t != null &&
                    !t.IsAbstract &&
                    typeof(DebugButtonBase).IsAssignableFrom(t))
                .ToList()!;
#else            
            return new List<Type>();
#endif
        }

        private void Awake()
        {
            SetUpButtons();
        }

        private void SetUpButton(string name, string tooltip, bool requiresMaster, UnityAction call, KeyCode hotkey)
        {
#if DEBUG
            buttons.Add(new DebugButtonData
            {
                Name = name,
                Tooltip = tooltip,
                RequiresMaster = requiresMaster,
                Call = call,
                Hotkey = hotkey
            });
#endif
        }

        private void Update()
        {
            if (Input.GetKeyDown(KeyCode.F1))
            {
                showMenu = !showMenu;
            }

#if DEBUG
            if (Input.GetKey(ModifierKey))
            {
                foreach (var button in buttons)
                {
                    if (button.Hotkey != KeyCode.None && Input.GetKeyDown(button.Hotkey))
                    {
                        ExecuteButton(button);
                    }
                }
            }
#endif
        }

        public void SetUpButtons()
        {
#if DEBUG
            buttons.Clear();

            var buttonTypes = GetAllDebugButtons();
            int keyIndex = 0;

            foreach (var type in buttonTypes)
            {
                var instance = (DebugButtonBase)Activator.CreateInstance(type);

                KeyCode assignedKey = KeyCode.None;
                if (keyIndex < availableKeys.Length)
                {
                    assignedKey = availableKeys[keyIndex];
                    keyIndex++;
                }

                SetUpButton(
                    instance.Name,
                    string.Empty,
                    instance.RequiresMaster,
                    instance.OnClick,
                    assignedKey
                );
            }
#endif
        }

        private void ExecuteButton(DebugButtonData button)
        {
#if DEBUG
            if (button.RequiresMaster && !DAHGDBPKKAJ.BOFPAFCGDCI)
            {
                SingletonMonoBehaviour<ScreenSpaceNotificationManager>.OJAGNDKABPJ.Play(
                    ScreenSpaceNotificationManager.AMLKMKALLEB.Minor,
                    "Only the master can use that",
                    Color.magenta,
                    3f,
                    null
                );
                return;
            }

            try
            {
                button.Call?.Invoke();
            }
            catch (Exception e)
            {
                Debug.LogException(e);

                SingletonMonoBehaviour<ScreenSpaceNotificationManager>.OJAGNDKABPJ.Play(
                    ScreenSpaceNotificationManager.AMLKMKALLEB.Vital,
                    $"OHHH NOOOO A ERROR\n\n{e.GetType().Name}: {e.Message}",
                    Color.red,
                    5f,
                    null
                );
            }
#endif
        }

        private void OnGUI()
        {
#if DEBUG
            if (!showMenu)
                return;

            GUI.Box(new Rect(10, 10, 350, 500), "Moew :3 [F1]");

            GUILayout.BeginArea(new Rect(20, 40, 330, 450));
            scrollPos = GUILayout.BeginScrollView(scrollPos);

            foreach (var button in buttons)
            {
                string hotkeyString = "";
                if (button.Hotkey != KeyCode.None)
                {
                    string keyName = button.Hotkey.ToString().Replace("Alpha", "");
                    hotkeyString = $" [Ctrl + {keyName}]";
                }

                string displayName = $"{button.Name}{hotkeyString}";
                GUIContent content = new(displayName, button.Tooltip);

                if (GUILayout.Button(content, GUILayout.Height(40)))
                {
                    ExecuteButton(button);
                }
            }

            GUILayout.EndScrollView();

            GUILayout.Label(GUI.tooltip);

            GUILayout.EndArea();
#endif
        }
    }
}