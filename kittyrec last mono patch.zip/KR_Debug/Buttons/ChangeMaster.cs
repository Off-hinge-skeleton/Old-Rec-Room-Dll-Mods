﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

namespace KittyRec.KR_Debug.Buttons
{
    internal class ChangeMaster : DebugButtonBase
    {
        public override string Name => "Change Master";
        //public override string Tooltip => "Use to change photon master";

        public override void OnClick()
        {
            LOJPOHGPJKO OldMaster = DAHGDBPKKAJ.AIKHEMCDGPD;

            LOJPOHGPJKO NewMaster = PUNNetworkManager.OJAGNDKABPJ.DebugChangeMasterClient();

            string newText = $"Old master: {OldMaster.LMDMMAJAMJF}\nNew master: {NewMaster.LMDMMAJAMJF}";
            SingletonMonoBehaviour<ScreenSpaceNotificationManager>.OJAGNDKABPJ.Play(ScreenSpaceNotificationManager.AMLKMKALLEB.Minor, newText, Color.magenta, 3f, null);
        }
    }
}
