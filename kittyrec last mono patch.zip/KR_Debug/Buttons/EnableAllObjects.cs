﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace KittyRec.KR_Debug.Buttons
{
    internal class EnableAllObjects : DebugButtonBase
    {
        public override string Name => "Enable All Objects";
        //public override string Tooltip => "Activates all scene objects except UI and cameras";

        public override void OnClick()
        {
            var activeScene = SceneManager.GetActiveScene();
            var allObjects = Resources.FindObjectsOfTypeAll<GameObject>();

            foreach (GameObject obj in allObjects)
            {
                if (!obj.scene.IsValid() || obj.scene.name == "DontDestroyOnLoad")
                    continue;
                
                if (obj.GetComponent<Camera>() != null) continue;

                obj.SetActive(true);
            }
        }
    }
}