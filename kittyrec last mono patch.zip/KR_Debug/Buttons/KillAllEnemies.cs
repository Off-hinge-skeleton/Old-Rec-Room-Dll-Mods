﻿using RecRoom.Core.AI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

namespace KittyRec.KR_Debug.Buttons
{
    internal class KillAllEnemies : DebugButtonBase
    {
        public override string Name => "Kill All Enemies";
        //public override string Tooltip => "Use to kill all enemies";
        public override bool RequiresMaster => true;

        public override void OnClick()
        {
            Enemy[] ais = UnityEngine.Object.FindObjectsOfType<Enemy>();
            int cont = ais.Length;
            foreach (Enemy enemy in ais)
            {
                Enemy.MasterKill(enemy);
            }
            SingletonMonoBehaviour<ScreenSpaceNotificationManager>.OJAGNDKABPJ.Play(ScreenSpaceNotificationManager.AMLKMKALLEB.Minor, $"Killed {cont} enemies", Color.magenta, 3f, null);
        }
    }
}