﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

namespace KittyRec.KR_Debug.Buttons
{
    internal class Unlit : DebugButtonBase
    {
        public override string Name => "Unlit";
        //public override string Tooltip => "Toggles unlit rendering";

        public bool unlitEnabled = false;

        public override void OnClick()
        {
            unlitEnabled = !unlitEnabled;

            if (unlitEnabled)
                Camera.main.SetReplacementShader(Shader.Find("Unlit/Texture"), null);
            else
                Camera.main.ResetReplacementShader();
        }
    }
}