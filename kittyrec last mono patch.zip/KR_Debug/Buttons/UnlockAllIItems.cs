﻿using AGUI.StackedUI.Dialog;
using RecRoom.Async;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

namespace KittyRec.KR_Debug.Buttons
{
    internal class UnlockAllIItems : DebugButtonBase
    {
        public override string Name => "Unlock All Items";

        private static void ICDBNOJPIGK(OutfitSelection KJIMHKNFGDB)
        {
            NetworkedSingletonMonoBehaviour<OutfitManager>.OJAGNDKABPJ.AddAvatarItemToUnlockedList(KJIMHKNFGDB.ToString(), 0);
        }

        private static void ENCDCDNKEFI(OutfitItem MAKJCGGIILL)
        {
            ICDBNOJPIGK(new OutfitSelection(MAKJCGGIILL, null, null, null));
            int num = 1;
            if (MAKJCGGIILL.SelectionGroups != null)
            {
                for (int i = 0; i < MAKJCGGIILL.SelectionGroups.Length; i++)
                {
                    OutfitItem.OutfitSelectionGroup outfitSelectionGroup = MAKJCGGIILL.SelectionGroups[i];
                    if (outfitSelectionGroup.IsValid)
                    {
                        for (int j = 0; j <= outfitSelectionGroup.decals.Count; j++)
                        {
                            for (int k = 0; k < outfitSelectionGroup.masks.Count; k++)
                            {
                                for (int l = 0; l < outfitSelectionGroup.swatches.Count; l++)
                                {
                                    ICDBNOJPIGK(new OutfitSelection(MAKJCGGIILL, (l >= outfitSelectionGroup.swatches.Count) ? null : outfitSelectionGroup.swatches[l], (k >= outfitSelectionGroup.masks.Count) ? null : outfitSelectionGroup.masks[k], (j >= outfitSelectionGroup.decals.Count) ? null : outfitSelectionGroup.decals[j]));
                                    num++;
                                }
                            }
                        }
                    }
                }
            }
        }
        private static void CKOLIHIHFHJ(GPJLBOFPGOI GJAPMDIMMKN)
        {
            if (GJAPMDIMMKN == GPJLBOFPGOI.Affirmative)
            {
                for (int j = 0; j < NetworkedSingletonMonoBehaviour<OutfitManager>.OJAGNDKABPJ.EDKMDJJABHF.Count; j++)
                {
                    OutfitItem outfitItem2 = NetworkedSingletonMonoBehaviour<OutfitManager>.OJAGNDKABPJ.EDKMDJJABHF[j];
                    ENCDCDNKEFI(outfitItem2);
                }

                /*foreach (EquipmentManager.ToolEquipmentSkins toolEquipment in NetworkedSingletonMonoBehaviour<EquipmentManager>.OJAGNDKABPJ.ToolSkinMaps)
                {
                    foreach (EquipmentSkin equipmentSkin in toolEquipment.skins)
                    {
                        NetworkedSingletonMonoBehaviour<EquipmentManager>.OJAGNDKABPJ.UpdateUnlockedEquipmentsFor(toolEquipment.friendlyName, equipmentSkin.Guid, 0);
                    }
                }*/
            }
        }


        public override void OnClick()
        {
            BJHEOHEBCGJ<GPJLBOFPGOI> lllll = Player.LocalPlayer.ODMDCKNKBKA.HMHHGIIDCLD.ShowConfirmationDialog("Unlock All Items", "Are you sure?");


            lllll.HAIKOBOEBJO(CKOLIHIHFHJ);
        }
    }
}