﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KittyRec.KR_Debug
{
    abstract class DebugButtonBase
    {
        public abstract string Name { get; }
        //public virtual string Tooltip => null;
        public virtual bool RequiresMaster => false;

        public abstract void OnClick();
    }
}
