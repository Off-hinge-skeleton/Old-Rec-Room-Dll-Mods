﻿using KittyRec.UI;
using RecRoom.Core.AI;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace KittyRec.KR_Debug
{
    internal class ItemSpawner : KR_UiBase
    {
        private GameObject panel;
        private GameObject ItemContent;
        private GameObject AiContent;
        private ScrollRect mainScrollRect;

        protected override void Awake()
        {
            base.Awake();
            CreateOverlayUI();

            if (panel != null)
            {
                panel.SetActive(false);
            }
        }

        private void Update()
        {
            if (Input.GetKeyDown(KeyCode.F2) && panel != null)
            {
                panel.SetActive(!panel.activeSelf);
            }
            if (panel.activeSelf)
            {
                if (Input.GetKeyDown(KeyCode.Alpha0) && panel != null && ItemContent != null && AiContent != null)
                {
                    if (ItemContent.activeSelf)
                    {
                        ItemContent.SetActive(false);
                        AiContent.SetActive(true);
                        if (mainScrollRect != null) mainScrollRect.content = AiContent.GetComponent<RectTransform>();
                    }
                    else if (AiContent.activeSelf)
                    {
                        AiContent.SetActive(false);
                        ItemContent.SetActive(true);
                        if (mainScrollRect != null) mainScrollRect.content = ItemContent.GetComponent<RectTransform>();
                    }
                    else
                    {
                        ItemContent.SetActive(true);
                        AiContent.SetActive(false);
                        if (mainScrollRect != null) mainScrollRect.content = ItemContent.GetComponent<RectTransform>();
                    }
                }
            }
        }

        private static EnemyConfig.Config AJOLDLJHPAG(PCMEGNMAHNA GEFLMAHGLMH)
        {
            if (GJBCMPHENNI.AOGFPFHECKJ != null && GJBCMPHENNI.AOGFPFHECKJ.Enemies != null && GEFLMAHGLMH >= PCMEGNMAHNA.QUEST_GOBLIN_BASIC_GROUND_MELEE && GEFLMAHGLMH < (PCMEGNMAHNA)GJBCMPHENNI.AOGFPFHECKJ.Enemies.Length)
            {
                return GJBCMPHENNI.AOGFPFHECKJ.Enemies[(int)GEFLMAHGLMH];
            }
            return null;
        }

        private GameObject CreateItemUI(GameObject viewport, RectTransform viewportRect)
        {
            GameObject content = new GameObject("ItemContent");
            content.transform.SetParent(viewport.transform, false);

            RectTransform contentRect = content.AddComponent<RectTransform>();
            contentRect.anchorMin = new Vector2(0, 1);
            contentRect.anchorMax = new Vector2(1, 1);
            contentRect.pivot = new Vector2(0.5f, 1);

            VerticalLayoutGroup layout = content.AddComponent<VerticalLayoutGroup>();
            layout.spacing = 5;
            layout.padding = new RectOffset(5, 5, 5, 5);
            layout.childAlignment = TextAnchor.UpperCenter;
            layout.childControlHeight = true;
            layout.childControlWidth = true;
            layout.childForceExpandHeight = false;

            ContentSizeFitter fitter = content.AddComponent<ContentSizeFitter>();
            fitter.verticalFit = ContentSizeFitter.FitMode.PreferredSize;

            foreach (BLLFBPHNCGA item in System.Enum.GetValues(typeof(BLLFBPHNCGA)))
            {
                if (item == BLLFBPHNCGA.INVALID)
                    continue;

                SpawnableToolConfig.Config config = GMADPLFPAIO.LOIBJHNHCHP(item);
                if (config == null)
                    continue;

                Button btn = CreateButton(content.transform, config.FriendlyName, () => OnItemClicked(item));

                RectTransform btnRect = btn.GetComponent<RectTransform>();
                btnRect.sizeDelta = new Vector2(0, 36);

                LayoutElement le = btn.gameObject.AddComponent<LayoutElement>();
                le.minHeight = 36;
                le.preferredHeight = 36;
                le.flexibleWidth = 1;

                Image img = btn.GetComponent<Image>();
                img.color = new Color(0.18f, 0.18f, 0.18f, 0.95f);
            }
            return content;
        }

        private GameObject CreateAiUI(GameObject viewport, RectTransform viewportRect)
        {
            GameObject content = new GameObject("AiContent");
            content.transform.SetParent(viewport.transform, false);

            RectTransform contentRect = content.AddComponent<RectTransform>();
            contentRect.anchorMin = new Vector2(0, 1);
            contentRect.anchorMax = new Vector2(1, 1);
            contentRect.pivot = new Vector2(0.5f, 1);

            VerticalLayoutGroup layout = content.AddComponent<VerticalLayoutGroup>();
            layout.spacing = 5;
            layout.padding = new RectOffset(5, 5, 5, 5);
            layout.childAlignment = TextAnchor.UpperCenter;
            layout.childControlHeight = true;
            layout.childControlWidth = true;
            layout.childForceExpandHeight = false;

            ContentSizeFitter fitter = content.AddComponent<ContentSizeFitter>();
            fitter.verticalFit = ContentSizeFitter.FitMode.PreferredSize;

            foreach (PCMEGNMAHNA item in System.Enum.GetValues(typeof(PCMEGNMAHNA)))
            {
                if (item == PCMEGNMAHNA.INVALID)
                    continue;

                EnemyConfig.Config config = AJOLDLJHPAG(item);
                if (config == null)
                    continue;

                Button btn = CreateButton(content.transform, config.FriendlyName, () => OnAiClicked(item));

                RectTransform btnRect = btn.GetComponent<RectTransform>();
                btnRect.sizeDelta = new Vector2(0, 36);

                LayoutElement le = btn.gameObject.AddComponent<LayoutElement>();
                le.minHeight = 36;
                le.preferredHeight = 36;
                le.flexibleWidth = 1;

                Image img = btn.GetComponent<Image>();
                img.color = new Color(0.18f, 0.18f, 0.18f, 0.95f);
            }
            return content;
        }

        private void CreateOverlayUI()
        {
            panel = CreatePanel(canvasObj.transform, new Vector2(260, 380), new Color(0f, 0f, 0f, 0.75f));
            AddVerticalLayout(panel);

            CreateText(panel.transform, "Spawner (F2)", 18, Color.white);

            GameObject scrollViewObj = new GameObject("ScrollView");
            scrollViewObj.transform.SetParent(panel.transform, false);

            RectTransform scrollRectTransform = scrollViewObj.AddComponent<RectTransform>();
            scrollRectTransform.anchorMin = new Vector2(0, 0);
            scrollRectTransform.anchorMax = new Vector2(1, 1);
            scrollRectTransform.pivot = new Vector2(0.5f, 0.5f);

            LayoutElement scrollLayout = scrollViewObj.AddComponent<LayoutElement>();
            scrollLayout.flexibleHeight = 1f;
            scrollLayout.flexibleWidth = 1f;

            Image scrollImage = scrollViewObj.AddComponent<Image>();
            scrollImage.color = new Color(0f, 0f, 0f, 0.2f);

            Mask mask = scrollViewObj.AddComponent<Mask>();
            mask.showMaskGraphic = false;

            mainScrollRect = scrollViewObj.AddComponent<ScrollRect>();
            mainScrollRect.horizontal = false;
            mainScrollRect.scrollSensitivity = 25f;
            mainScrollRect.movementType = ScrollRect.MovementType.Clamped;
            mainScrollRect.inertia = true;
            mainScrollRect.decelerationRate = 0.135f;

            GameObject viewport = new GameObject("Viewport");
            viewport.transform.SetParent(scrollViewObj.transform, false);

            RectTransform viewportRect = viewport.AddComponent<RectTransform>();
            viewportRect.anchorMin = Vector2.zero;
            viewportRect.anchorMax = Vector2.one;
            viewportRect.offsetMin = Vector2.zero;
            viewportRect.offsetMax = Vector2.zero;

            Image viewportImage = viewport.AddComponent<Image>();
            viewportImage.color = new Color(1, 1, 1, 0.01f);

            Mask viewportMask = viewport.AddComponent<Mask>();
            viewportMask.showMaskGraphic = false;

            mainScrollRect.viewport = viewportRect;

            ItemContent = CreateItemUI(viewport, viewportRect);
            AiContent = CreateAiUI(viewport, viewportRect);

            ItemContent.SetActive(true);
            AiContent.SetActive(false);

            mainScrollRect.content = ItemContent.GetComponent<RectTransform>();
        }

        private void OnItemClicked(BLLFBPHNCGA item)
        {
            string itemPrefab = GMADPLFPAIO.FBDPGCJAOBI(item);

            Vector3 spawnPos = Player.LocalPlayer.PDPIABLKEJA.transform.position;

            DAHGDBPKKAJ.BKPIFNEHFLL(itemPrefab, spawnPos, Quaternion.identity, 1f, 0);

            SingletonMonoBehaviour<ScreenSpaceNotificationManager>.OJAGNDKABPJ.Play(
                 ScreenSpaceNotificationManager.AMLKMKALLEB.Minor,
                 $"Spawned {itemPrefab}",
                 Color.magenta,
                 3f,
                 null
            );
        }

        private void OnAiClicked(PCMEGNMAHNA item)
        {
            string itemPrefab = GJBCMPHENNI.JOIJBHBIPLD(item);

            Vector3 spawnPos = Player.LocalPlayer.PDPIABLKEJA.transform.position;

            Enemy enemy = Enemy.MasterSpawn(item, spawnPos, Quaternion.identity, spawnPos, false, null, NetworkedSingletonMonoBehaviour<GameManager>.OJAGNDKABPJ.BAECIMLKJDA.OIJOBNKFPHK(Player.LocalPlayer.LOJPOHGPJKO), false, 0, new Dictionary<string, object>());
            SingletonMonoBehaviour<ScreenSpaceNotificationManager>.OJAGNDKABPJ.Play(ScreenSpaceNotificationManager.AMLKMKALLEB.Minor, $"Spawned {enemy.name}", Color.magenta, 3f, null);
        }
    }
}