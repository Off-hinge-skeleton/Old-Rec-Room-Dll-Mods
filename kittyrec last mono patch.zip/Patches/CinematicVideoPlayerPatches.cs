﻿using HarmonyLib;
using RecRoom.Core.Cinematics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KittyRec.Patches
{
    internal class CinematicVideoPlayerPatches
    {
        [HarmonyPatch(typeof(CinematicVideoPlayer), "Start")]
        public static class RemoveVideoAntiTamperHash
        {
            [HarmonyPrefix]
            private static bool Prefix(CinematicVideoPlayer __instance, ref bool ___useAntiTamperHash)
            {
                ___useAntiTamperHash = false;
                return true;
            }
        }

        [HarmonyPatch(typeof(CinematicVideoPlayer), "CNFCJFCHKPD")]
        public static class VideoYea
        {
            [HarmonyPrefix]
            private static bool Prefix(CinematicVideoPlayer __instance, ref string __result)
            {
                __result = $"http://kittyrec.tabbycluster.net/{__instance.streamingAssetsMoviePath}";
                return false;
            }
        }
    }
}
