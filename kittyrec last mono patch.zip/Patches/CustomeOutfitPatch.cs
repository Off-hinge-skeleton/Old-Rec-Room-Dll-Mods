﻿using RecRoom.Players;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HarmonyLib;

namespace KittyRec.Patches
{
    [HarmonyPatch(typeof(OutfitManager), "Awake")]
    internal class CustomeOutfitPatch
    {
        [HarmonyPrefix]
        public static void Prefix(ref List<OutfitItem> ___outfitPrefabs)
        {
            OutfitItem outfitItem = null;
            foreach (OutfitItem item in ___outfitPrefabs)
            {
                if (item.name.StartsWith("[MaleTShirt]"))
                {
                    outfitItem = item;
                    break;
                }
            }
            if (outfitItem != null)
            {

            }
        }
    }
}
