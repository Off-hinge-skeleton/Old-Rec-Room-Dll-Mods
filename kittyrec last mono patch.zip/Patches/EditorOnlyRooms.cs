﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using HarmonyLib;

namespace KittyRec.Patches
{
    [HarmonyPatch(typeof(MBCEJNEHLNI), "CIFKJKLNILL", MethodType.Getter)]
    internal class EditorOnlyRooms
    {
        [HarmonyPrefix]
        static bool Prefix(bool __result)
        {
            __result = true;
            return false;
        }
    }

}
