﻿using HarmonyLib;
using RecRoom.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace KittyRec.Patches
{
    [HarmonyPatch(typeof(CameraRig), "CDIPCFIHAJA")]
    internal class FixCameraRig
    {
        [HarmonyPrefix]
        public static void Prefix(ref Camera ___vrModeHmdCamera, ref Camera ___screenModeCamera)
        {
            ___vrModeHmdCamera.tag = "MainCamera";
            ___screenModeCamera.tag = "MainCamera";
        }
    }
}
