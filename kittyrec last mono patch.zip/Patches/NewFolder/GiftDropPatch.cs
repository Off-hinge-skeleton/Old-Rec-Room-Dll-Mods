﻿using RecNet;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HarmonyLib;

namespace KittyRec.Patches.NewFolder
{
    [HarmonyPatch(typeof(EDBLEKCLJKK), nameof(EDBLEKCLJKK.Deserialize))]
    internal class GiftDropPatch
    {
        public static void Postfix(EDBLEKCLJKK __instance, Dictionary<string, object> FODLMPDGEKH)
        {
            if (FODLMPDGEKH != null && FODLMPDGEKH.ContainsKey("FriendlyName"))
            {
                string originalName = DNBLGJBDPKN.MAGJEEOECHI<string>("FriendlyName", FODLMPDGEKH);
                Traverse.Create(__instance).Property("BHEBMGEOKAH").SetValue(originalName);
            }
        }
    }
}
