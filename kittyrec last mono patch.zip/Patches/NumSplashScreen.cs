﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HarmonyLib;
using UnityEngine;

namespace KittyRec.Patches
{
    [HarmonyPatch(typeof(SplashScreenManager), "KMLKHALFBAD")]
    internal class NumSplashScreen
    {
        [HarmonyPrefix]
        public static bool Prefix(ref float ___minSplashDuration, ref GameObject ___NUXSplashScreen, ref GameObject ___normalSplashScreen, ref RecRoomAudioClip ___NGHCLMDNOGK, ref RecRoomAudioClip ___NUXSplashScreenAudio)
        {
            ___minSplashDuration = 0f;
            ___NUXSplashScreen.SetActive(true);
            ___normalSplashScreen.SetActive(false);
            ___NGHCLMDNOGK = ___NUXSplashScreenAudio;
            return false;
        }
    }
}
