﻿using RecRoom.Systems;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HarmonyLib;

namespace KittyRec.Patches.Player
{
    internal class InputPatch
    {
        [HarmonyPatch(typeof(InputManager), "PPEFKMOBJDJ")]
        public class ScreenInput
        {
            [HarmonyPrefix]
            public static bool Prefix(ref InputManager.EOFBGKDIGMG __result)
            {
                string text = PUNNetworkManager.CheckCommandLineArgsFor("+screenInput:");

                if (string.IsNullOrEmpty(text))
                {
                    return true;
                }

                switch (text)
                {
                    case "pc":
                        __result = InputManager.EOFBGKDIGMG.PC;
                        return false;
                    case "dualshock":
                        __result = InputManager.EOFBGKDIGMG.PS4_DualShock;
                        return false;
                    case "off":
                        __result = InputManager.EOFBGKDIGMG.Off;
                        return false;
                }

                return true;
            }
        }

        [HarmonyPatch(typeof(InputManager), "KGGJPMOFIIJ")]
        public class VrInput
        {
            [HarmonyPrefix]
            public static bool Prefix(ref InputManager.ABCKDHEOEAN __result)
            {
                string text = PUNNetworkManager.CheckCommandLineArgsFor("+vrInput:");

                if (string.IsNullOrEmpty(text))
                {
                    return true;
                }

                switch (text)
                {
                    case "off":
                        __result = InputManager.ABCKDHEOEAN.Off;
                        return false;
                    case "debug":
                        __result = InputManager.ABCKDHEOEAN.Debug;
                        return false;
                    case "vive":
                        __result = InputManager.ABCKDHEOEAN.SteamVR_Vive;
                        return false;
                    case "steamvr_oculus":
                        __result = InputManager.ABCKDHEOEAN.SteamVR_Oculus;
                        return false;
                    case "steamvr_windows":
                        __result = InputManager.ABCKDHEOEAN.SteamVR_WindowsMR;
                        return false;
                    case "oculus":
                        __result = InputManager.ABCKDHEOEAN.Oculus;
                        return false;
                    case "move":
                        __result = InputManager.ABCKDHEOEAN.PS4_Move;
                        return false;
                    case "windows":
                        __result = InputManager.ABCKDHEOEAN.WindowsMR;
                        return false;
                }

                return true;
            }
        }
    }
}
