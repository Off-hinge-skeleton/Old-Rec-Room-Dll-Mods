﻿using HarmonyLib;
using RecRoom.Core;
using RecRoom.Players;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace KittyRec.Patches.Player
{
    [HarmonyPatch(typeof(PlayerBody), "Awake")]
    internal class PlayerBodyPatch
    {
        [HarmonyPrefix]
        public static void Prefix(
                ref float ___minPitch,
                ref float ___maxPitch,
                ref float ___minYaw,
                ref float ___maxYaw,
                ref float ___maxForwardYaw,
                ref float ___WalkingAnimationMultiplier)
        {
            ___minPitch = -360f;
            ___maxPitch = 360f;
            ___minYaw = -360f;
            ___maxYaw = 360f;
            ___maxForwardYaw = 360f;
            //___walkingAnimationMultiplier = 5.0f;
        }
    }
}
