﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HarmonyLib;
using UnityEngine;
using Photon;

namespace KittyRec.Patches
{
    [HarmonyPatch(typeof(Resources), "Load", [typeof(string), typeof(Type)])]
    internal class ResourcesLoadPatch
    {
        [HarmonyPostfix]
        static void Postfix(string path, Type systemTypeInstance, ref UnityEngine.Object __result)
        {
            if (path == "PhotonServerSettings")
            {
                var settings = __result as ServerSettings;
                if (settings != null)
                {
                    settings.AppID = "416d49c9-30c4-476d-b462-ad794221fd90";
                    settings.VoiceAppID = "5deee059-71d4-436a-8957-ee6c925f0d5f";
#if DEBUG
                    //settings.NetworkLogging = ExitGames.Client.Photon.DebugLevel.ALL;
                    //settings.PunLogging = DGNJCNPDGHM.Full;
#endif
                }
                return;
            }
        }
    }

}
