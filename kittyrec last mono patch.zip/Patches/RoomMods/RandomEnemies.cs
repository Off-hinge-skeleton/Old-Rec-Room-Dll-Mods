﻿using HarmonyLib;
using RecNet;
using RecRoom.Core.AI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KittyRec.Patches.RoomMods
{
    internal class RandomEnemies
    {
        [HarmonyPatch(typeof(Enemy), "MasterSpawn")]
        class RandomEnemiesP
        {
            private static readonly HashSet<PCMEGNMAHNA> Blacklist = new()
            {
                PCMEGNMAHNA.INVALID,
                PCMEGNMAHNA.QUEST_PIRATE_BOSS,
                PCMEGNMAHNA.QUEST_GOBLIN_WITCH_BOSS,
                PCMEGNMAHNA.QUEST_GOBLIN_VOLLEY,
                PCMEGNMAHNA.QUEST_SCIFI_KNIGHT_ASSASSIN,
                PCMEGNMAHNA.ARENA_MAINFRAME,
                PCMEGNMAHNA.QUEST_SCIFI_JUMBOTRON
            };

            private static readonly PCMEGNMAHNA[] ValidEnemies = Enum.GetValues(typeof(PCMEGNMAHNA)).Cast<PCMEGNMAHNA>().Where(e => !Blacklist.Contains(e)).ToArray();
            [HarmonyPrefix]
            public static bool Prefix(ref PCMEGNMAHNA GEFLMAHGLMH)
            {
                if (!EMBELFFPLDJ.GJOJFGMLOEA.GFAHLFAOOGF.Contains("<randomenemies>"))
                    return true;

                if (ValidEnemies.Length == 0)
                    return true;

                GEFLMAHGLMH = ValidEnemies[UnityEngine.Random.Range(0, ValidEnemies.Length)];
                return true;
            }
        }

    }
}
