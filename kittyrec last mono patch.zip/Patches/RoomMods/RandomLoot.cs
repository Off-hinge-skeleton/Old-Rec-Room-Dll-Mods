﻿using HarmonyLib;
using RecNet;
using RecRoom.Core.GameManagement;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KittyRec.Patches.RoomMods
{
    internal class RandomLoot
    {
        /*[HarmonyPatch(typeof(LootManager), "CLDHHNIFPPL")]
        class RandomLoot1
        {
            private static readonly HashSet<BLLFBPHNCGA> Blacklist = new()
            {
                BLLFBPHNCGA.INVALID,
                BLLFBPHNCGA.SANDBOX_WALL,
                BLLFBPHNCGA.SANDBOX_WALL_WINDOW,
                BLLFBPHNCGA.SANDBOX_CEILING,
                BLLFBPHNCGA.SANDBOX_FLOOR
            };

            private static readonly BLLFBPHNCGA[] ValidEnemies = Enum.GetValues(typeof(BLLFBPHNCGA)).Cast<BLLFBPHNCGA>().Where(e => !Blacklist.Contains(e)).ToArray();
            [HarmonyPrefix]
            public static bool Prefix(ref BLLFBPHNCGA KEIAEHCDGCI)
            {
                if (!EMBELFFPLDJ.GJOJFGMLOEA.GFAHLFAOOGF.Contains("<randomloot>"))
                    return true;

                if (ValidEnemies.Length == 0)
                    return true;

                KEIAEHCDGCI = ValidEnemies[UnityEngine.Random.Range(0, ValidEnemies.Length)];
                return true;
            }
        }*/

    }
}
