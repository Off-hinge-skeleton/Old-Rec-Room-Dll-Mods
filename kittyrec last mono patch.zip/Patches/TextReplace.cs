﻿using Google.Protobuf.WellKnownTypes;
using HarmonyLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace KittyRec.Patches
{
    internal class TextReplace
    {
        public static string Replace(string text)
        {
            if (text.ToLower().Contains("recroomoriginal"))
            {
                return text;
            }
            return text.Replace("RecRoom", "KittyRec").Replace("Rec Room", "KittyRec").Replace("RecNet", "KittyNet");
        }

        [HarmonyPatch(typeof(TMP_Text), "set_text")]
        public static class TMPset_text
        {
            [HarmonyPrefix]
            static void Prefix(ref string value)
            {
                if (value == null) return;
                value = Replace(value);
            }
        }

        [HarmonyPatch(typeof(TextMesh), "set_text")]
        public static class TextMeshset_text
        {
            [HarmonyPrefix]
            static void Prefix(ref string value)
            {
                if (value == null) return;
                value = Replace(value);
            }
        }

        [HarmonyPatch(typeof(Text), "set_text")]
        public static class TextMset_text
        {
            [HarmonyPrefix]
            static void Prefix(ref string value)
            {
                if (value == null) return;
                value = Replace(value);
            }
        }
    }
}
