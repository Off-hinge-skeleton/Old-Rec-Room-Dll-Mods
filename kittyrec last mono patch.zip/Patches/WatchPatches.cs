﻿using AGUI;
using AGUI.StackedUI;
using HarmonyLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Tilemaps;
using RecNet;

namespace KittyRec.Patches
{
    internal class WatchPatches
    {
        [HarmonyPatch(typeof(WatchUI), "SetBackgroundColors")]
        class backg
        {
            [HarmonyPrefix]
            public static bool Prefix(ref Color __0, ref Color __1)
            {
                __0 = Color.magenta;
                __1 = Color.grey;
                return true;
            }
        }
        [HarmonyPatch(typeof(ProfileSelectionStackedUI), "SetBackgroundColors")]
        class backg2
        {
            [HarmonyPrefix]
            public static bool Prefix(ref Color __0, ref Color __1)
            {
                __0 = Color.magenta;
                __1 = Color.grey;
                return true;
            }
        }
        [HarmonyPatch(typeof(ToolUI), "SetBackgroundColors")]
        class backg3
        {
            [HarmonyPrefix]
            public static bool Prefix(ref Color __0, ref Color __1)
            {
                __0 = Color.magenta;
                __1 = Color.grey;
                return true;
            }
        }

        [HarmonyPatch(typeof(ProfileSelectionStackedUI), "Start")]
        class backg12
        {
            [HarmonyPostfix]
            static void Postfix(ProfileSelectionStackedUI __instance)
            {
                __instance.SetBackgroundColors(Color.magenta, Color.gray);
            }
        }

        [HarmonyPatch(typeof(ToolUI), "Start")]
        class backg13
        {
            [HarmonyPostfix]
            static void Postfix(ToolUI __instance)
            {
                __instance.SetBackgroundColors(Color.magenta, Color.gray);
            }
        }

        [HarmonyPatch(typeof(SavedOutfitsWatchUIFlow), "Initialize")]
        class MoreSlotsPatch
        {
            static FieldInfo slotIndexField = typeof(UISavedOutfitSlot).GetField("slotIndex", BindingFlags.NonPublic | BindingFlags.Instance);
            [HarmonyPrefix]
            static void Prefix(SavedOutfitsWatchUIFlow __instance)
            {
                UISavedOutfitSlot template = __instance.GetComponentInChildren<UISavedOutfitSlot>();
                if (template == null) return;

                for (int i = 1000; i <= 1020; i++)
                {
                    CreateSlot(__instance, template, i);
                }
            }

            static void CreateSlot(SavedOutfitsWatchUIFlow instance, UISavedOutfitSlot template, int index)
            {
                GameObject newObj = UnityEngine.Object.Instantiate(template.gameObject, template.transform.parent);

                slotIndexField.SetValue(newObj.GetComponent<UISavedOutfitSlot>(), index);

            }
        }

        public static Sprite LoadSprite(byte[] data)
        {
            Texture2D tex = new Texture2D(2, 2);
            if (ImageConversion.LoadImage(tex, data))
            {
                return Sprite.Create(tex, new Rect(0, 0, tex.width, tex.height), new Vector2(0.5f, 0.5f));
            }
            return null;
        }

        public static readonly Sprite kittyrecIcon = LoadSprite(Resource.kittyrec_icon);
        public static Sprite recroomIcon = Resources.FindObjectsOfTypeAll<Sprite>().FirstOrDefault(s => s.name == "RECFace");

        [HarmonyPatch(typeof(BrowseRoomsScreen), "ECEFAOONIBA")]
        class yy6y6y6
        {

            static void setButtonImage(ToggleButton3D button, Sprite sprite)
            {
                if (sprite == null) return;
                button.DJNDKENNKBL.gameObject.SetActive(false);
                button.SetConstantSprite(sprite);
            }

            [HarmonyPrefix]
            static bool Prefix(BrowseRoomsScreen __instance, ToggleButton3D[] ___BPNGJDKOCBI, List<string> ___OBAJJLNHEPA, Sprite ___agTagSprite)
            {
                for (int i = 0; i < ___BPNGJDKOCBI.Length; i++)
                {
                   ___BPNGJDKOCBI[i].gameObject.SetActive(i < Mathf.Min(___OBAJJLNHEPA.Count, (__instance.OODHPHLIINE.PKOPMMNFCPK != HNDBFEEDEHF.LARGE) ? 8 : 15));
                    if (i < ___OBAJJLNHEPA.Count)
                    {
                        if (___OBAJJLNHEPA[i] == "#recroomoriginal")
                        {
                            setButtonImage(___BPNGJDKOCBI[i], ___agTagSprite);
                        }
                        else if (___OBAJJLNHEPA[i] == "#kittyrecoriginal")
                        {
                            setButtonImage(___BPNGJDKOCBI[i], kittyrecIcon);
                        }

                        MINKMMLNOIE.DNICKGAOCHA(___BPNGJDKOCBI[i].DJNDKENNKBL, ___OBAJJLNHEPA[i]);
                        if (___OBAJJLNHEPA[i] == "#recroomoriginal")
                        {
                            Traverse.Create(__instance).Field("DEOMIKCANEC").SetValue(___BPNGJDKOCBI[i]);
                        }
                    }
                }
                return false;
            }
        }

        [HarmonyPatch(typeof(RoomButton), "SetRoom")]
        class trttrtr
        {
            [HarmonyPostfix]
            static void Postfix(RoomButton __instance, RecNet.BHPFINLJEEG FEHLAJPJCMK, int OHILEOBAAKA, List<string> IBIGEDKFHBH, RecNet.BHPFINLJEEG ___Room, Image ___agRoomImage)
            {
                if (recroomIcon == null)
                {
                    recroomIcon = ___agRoomImage.sprite;
                }
                if (___Room == null) return;

                if (___Room.BDACHKODFAL && (___Room.IDOLCKLJGCE.ToLower().Contains("kittyrecoriginal") || ___Room.JCIHIGFMDFH.ToLower().EndsWith("randomizer")))
                {
                    ___agRoomImage.sprite = kittyrecIcon;
                }
                else if (___Room.BDACHKODFAL)
                {
                    ___agRoomImage.sprite = recroomIcon;
                }
                return;
            }
        }
    }
}
