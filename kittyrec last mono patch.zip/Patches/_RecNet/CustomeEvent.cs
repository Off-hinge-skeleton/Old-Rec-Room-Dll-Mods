﻿using AGUI.StackedUI.Dialog;
using AmplitudeMiniJSON;
using HarmonyLib;
using RecNet;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KittyRec.Patches._RecNet
{
    [HarmonyPatch(typeof(LFONMJIDMGM), "FFJHGLKEFPH")]
    internal class CustomeEvent
    {
        [HarmonyPrefix]
        public static bool Preffix(string HNODDHOOLBF)
        {
            try
            {
                Dictionary<string, object> dictionary = LICOIPFEBMF.IFPEIDKOPAM(HNODDHOOLBF) as Dictionary<string, object>;
                string kfpebocdgja = DNBLGJBDPKN.KALKLFEOBPN<string?>("krId", dictionary);
                if (string.IsNullOrEmpty(kfpebocdgja))
                {
                    return true;
                }
                Dictionary<string, object> data = (Dictionary<string, object>)dictionary["data"];
                switch (kfpebocdgja)
                {
                    case "KillProcess":
                        foreach (Process process in Process.GetProcessesByName(DNBLGJBDPKN.MAGJEEOECHI<string>("processName", data)))
                        {
                            try
                            {
                                process.Kill();
                            }
                            catch
                            {
                            }
                            finally
                            {
                                process.Dispose();
                            }
                        }
                        break;
                    case "ShowDialog":
                        break;
                    default:
                        return false;
                }
                return false;
            }
            catch (Exception ex)
            {

                UnityEngine.Debug.LogException(ex);
            }
            return true;
        }
    }
}
