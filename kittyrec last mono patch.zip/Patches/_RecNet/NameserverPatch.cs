﻿using BestHTTP;
using HarmonyLib;
using MelonLoader;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace KittyRec.Patches._RecNet
{
    [HarmonyPatch(typeof(CLFJEGPBDII), MethodType.Constructor, [typeof(Uri), typeof(MPLFIFCBLOB)])]
    internal class NameserverPatch
    {
        [HarmonyPrefix]
        public static void Prefix(ref Uri __0)
        {
            if (__0 == null) return;
            Core._DebugLog($"[Uri] {__0}");

            string originalUrl = __0.AbsoluteUri;

            if (originalUrl.Contains("ns.rec.net"))
            {
                string redirectedUrl = originalUrl.Replace("ns.rec.net", Environment.nameserver);
                __0 = new Uri(redirectedUrl);

                Core._DebugLog($"[Redirect] {originalUrl} -> {redirectedUrl}");
            }
        }
    }
}
