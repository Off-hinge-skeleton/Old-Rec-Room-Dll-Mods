﻿using HarmonyLib;
using MelonLoader;
using RecRoom;
using RecRoom.Core.Cinematics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KittyRec.Patches._RecNet
{
    internal class RadioPatch
    {
        [HarmonyPatch(typeof(ProfileSelectionManager), "WaitForLogIn")]
        public static class jgrehuerjjr
        {
            [HarmonyPrefix]
            private static bool Prefix()
            {
                MelonCoroutines.Start(Radio.download());
                return true;
            }
        }

        [HarmonyPatch(typeof(RecRoom.Radio), "Start")]
        public static class RadioStartPatch
        {
            [HarmonyPrefix]
            private static bool Prefix(RecRoom.Radio __instance, ref SFXTrack[] ___tracks)
            {
                ___tracks = Radio.GetCustomTracks();

                return true;
            }
        }

    }
}
