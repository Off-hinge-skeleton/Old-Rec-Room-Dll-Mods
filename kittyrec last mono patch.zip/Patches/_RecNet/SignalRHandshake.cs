﻿using BestHTTP;
using BestHTTP.SignalRCore;
using HarmonyLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace KittyRec.Patches._RecNet
{
    [HarmonyPatch(typeof(DIFHHHINLCI), "GJHDFHOKEKI")]
    internal class SignalRHandshake
    {
        [HarmonyPrefix]
        public static void Prefix(ref string __0)
        {
            if (__0.Contains("protocol':"))
            {
                __0 = __0.Replace("'", "\"");
            }

        }
    }
}
