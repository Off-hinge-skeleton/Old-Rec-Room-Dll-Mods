﻿using HarmonyLib;
using RecNet;
using System;
using System.Reflection;
using System.Text;
using UnityEngine;

namespace KittyRec.Patches._RecNet
{
    [HarmonyPatch(typeof(EILONPGCMFP), nameof(EILONPGCMFP.KKHIKPEFJOA))]
    internal class VersionCheckInfoPatch
    {
        [HarmonyPrefix]
        public static bool Prefix(ref string __0)
        {
            if (string.IsNullOrEmpty(__0))
            {
                return true;
            }


            if (__0.StartsWith("api/versioncheck/v3")) {
                try
                {
                    string rrVersion = Uri.EscapeDataString(LACHJMJGMPK.PPEPNDPKGHN);
                    string rrBa = LACHJMJGMPK.IIGEOGFLCIP.ToString();

                    var platformMgr = SingletonMonoBehaviour<PlatformManager>.OJAGNDKABPJ;
                    string platform = platformMgr != null ? ((int)platformMgr.PCCKNGAMNEE).ToString() : "-1";

                    string kre = Uri.EscapeDataString(((int)Environment.type).ToString());
                    string krb = Uri.EscapeDataString(ThisAssembly.Git.Branch);
                    string krc = Uri.EscapeDataString(ThisAssembly.Git.Commit);

                    __0 = $"api/versioncheck/kittyrec?rrv={rrVersion}&rrba={rrBa}&p={platform}&kre={kre}&krb={krb}&krc={krc}";
                }
                catch (Exception ex)
                {
                    UnityEngine.Debug.LogError($"[KittyRec] VersionCheck Patch Failed: {ex.Message}");
                }
            }
            

            return true; 
        }
    }
}