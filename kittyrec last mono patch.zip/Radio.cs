﻿using HarmonyLib;
using MelonLoader;
using RecNet;
using RecRoom;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using UnityEngine;
using UnityEngine.Networking;

namespace KittyRec
{
    public class RadioDTO : EDOGKHFAKBD
    {
        public void Deserialize(Dictionary<string, object> Dict)
        {
            this.FriendlyName = DNBLGJBDPKN.MAGJEEOECHI<string>("friendlyName", Dict);
            this.FileName = DNBLGJBDPKN.MAGJEEOECHI<string>("fileName", Dict);
            this.FileType = (AudioType)DNBLGJBDPKN.MAGJEEOECHI<int>("fileType", Dict);
        }

        public string FriendlyName;
        public string FileName;
        public AudioType FileType;
    }

    public static class Radio
    {
        private static readonly FieldInfo FriendlyNameField = typeof(SFXTrack).GetField("friendlyName", BindingFlags.Instance | BindingFlags.NonPublic);
        private static readonly FieldInfo ClipField = typeof(SFXTrack).GetField("clip", BindingFlags.Instance | BindingFlags.NonPublic);

        public static List<SFXTrack> customTracks = new List<SFXTrack>();

        // Retry settings
        private const int MaxRetries = 5;
        private const float RetryDelaySeconds = 3.0f;

        public static SFXTrack[] GetCustomTracks() => customTracks.ToArray();

        private static IEnumerator DownloadAndSetupTrack(RadioDTO item)
        {
            string url = $"{BHOEHJMOOIP.JOIHPPIKJFM}/music/{item.FileName}";
            string savePath = Path.Combine(Application.persistentDataPath, item.FileName);
            bool downloadSuccess = false;

            // 1. DOWNLOAD PHASE (With Retry Logic)
            if (File.Exists(savePath))
            {
                downloadSuccess = true;
#if DEBUG
                MelonLogger.Msg($"[Radio] File exists: {item.FileName}. Skipping download.");
#endif
            }
            else
            {
                int attempts = 0;
                while (attempts < MaxRetries && !downloadSuccess)
                {
                    attempts++;
#if DEBUG
                    MelonLogger.Msg($"[Radio] Downloading {item.FriendlyName} (Attempt {attempts}/{MaxRetries})...");
#endif
                    using (UnityWebRequest www = UnityWebRequest.Get(url))
                    {
                        yield return www.SendWebRequest();

                        if (!www.isNetworkError && !www.isHttpError)
                        {
                            byte[] results = www.downloadHandler.data;
                            if (results != null && results.Length > 0)
                            {
                                File.WriteAllBytes(savePath, results);
                                downloadSuccess = true;
                            }
                        }
                        else
                        {
#if DEBUG
                            MelonLogger.Warning($"[Radio] Attempt {attempts} failed: {www.error}");
#endif
                            if (attempts < MaxRetries)
                            {
                                yield return new WaitForSeconds(RetryDelaySeconds);
                            }
                        }
                    }
                }
            }

            if (!downloadSuccess)
            {
#if DEBUG
                MelonLogger.Error($"[Radio] Permanently failed to download: {item.FriendlyName}");
#endif
                yield break;
            }

            AudioClip tmp = null;

            if (item.FileType == AudioType.WAV)
            {
                tmp = WavUtility.ToAudioClip(savePath);
            }
            else if (item.FileType == AudioType.MPEG || item.FileType == AudioType.OGGVORBIS)
            {
                using (UnityWebRequest req = UnityWebRequestMultimedia.GetAudioClip("file://" + savePath, item.FileType))
                {
                    yield return req.SendWebRequest();

                    if (req.isNetworkError || req.isHttpError)
                    {
#if DEBUG
                        MelonLogger.Error($"[Radio] Failed to load audio clip from disk: {req.error}");
#endif
                        yield break;
                    }

                    tmp = DownloadHandlerAudioClip.GetContent(req);
                }
            }

            if (tmp == null)
            {
#if DEBUG
                MelonLogger.Error($"[Radio] AudioClip resulted in null for {item.FriendlyName}");
#endif
                yield break;
            }

            tmp.name = item.FriendlyName;
            SFXTrack trackInstance = ScriptableObject.CreateInstance<SFXTrack>();

            ClipField?.SetValue(trackInstance, tmp);
            FriendlyNameField?.SetValue(trackInstance, item.FriendlyName);

            customTracks.Add(trackInstance);
#if DEBUG
            MelonLogger.Msg($"[Radio] Successfully loaded track: {item.FriendlyName}");
#endif
        }

        internal static void hi(string error, List<RadioDTO> data)
        {
            if (string.IsNullOrEmpty(error))
            {
                foreach (RadioDTO item in data)
                {
                    if (item.FileType != AudioType.WAV &&
                        item.FileType != AudioType.MPEG &&
                        item.FileType != AudioType.OGGVORBIS)
                    {
#if DEBUG
                        MelonLogger.Warning($"[Radio] Unsupported audio type: {item.FileType} for {item.FriendlyName}");
#endif
                        continue;
                    }

                    MelonCoroutines.Start(DownloadAndSetupTrack(item));
                }
            }
            else
            {
#if DEBUG
                MelonLogger.Error($"[Radio] Failed to fetch playlist: {error}");
#endif
            }
        }

        public static IEnumerator download()
        {
            yield return EILONPGCMFP.KKHIKPEFJOA("api/config/v1/playlist", false).OGLDBMIIAHP<RadioDTO>().NBDHHILLGPN(new EILONPGCMFP.NKMPOLBHDCC<List<RadioDTO>>(hi));
        }
    }
}