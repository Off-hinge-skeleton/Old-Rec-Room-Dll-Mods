﻿using RecRoom.Core.UI;
using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using UnityEngine.XR;

namespace KittyRec.UI
{
    internal class KR_UiBase : MonoBehaviour
    {
        protected GameObject canvasObj;

        [Header("VR Settings")]
        private float vrDistance = 1.5f;
        private float vrHorizontalOffset = -0.6f;
        private float vrVerticalOffset = 0.2f;
        private float smoothSpeed = 5.0f;

        private bool FakeVr = true;

        protected virtual void Awake()
        {
            canvasObj = CreateUI();
        }

        protected virtual void LateUpdate()
        {
            if (canvasObj != null && IsVREnabled())
                HandleVRFollow(canvasObj);
        }

        public virtual GameObject CreateUI()
        {
            return CreateCanvas("KR Canvas");
        }

        protected GameObject CreateCanvas(string name)
        {
            GameObject obj = new GameObject(name);
            DontDestroyOnLoad(obj);

            Canvas canvas = obj.AddComponent<Canvas>();
            canvas.renderMode = IsVREnabled()
                ? RenderMode.WorldSpace
                : RenderMode.ScreenSpaceOverlay;

            canvas.sortingOrder = 9999;
            canvas.worldCamera = UIInputModule.Instance.ControllerCamera;
            obj.AddComponent<CanvasScaler>();
            obj.AddComponent<VRCanvas>();
            obj.AddComponent<RecRoom.FastGraphicRaycaster>();

            if (IsVREnabled())
                obj.transform.localScale = Vector3.one * 0.002f;

            EnsureEventSystem();

            return obj;
        }

        protected GameObject CreatePanel(Transform parent, Vector2 size, Color color)
        {
            GameObject panel = new GameObject("Panel");
            panel.transform.SetParent(parent, false);

            Image img = panel.AddComponent<Image>();
            img.color = color;

            RectTransform rect = panel.GetComponent<RectTransform>();
            rect.sizeDelta = size;

            //if (draggable)
            //    panel.AddComponent<UIDragger>();

            return panel;
        }


        protected TextMeshProUGUI CreateText(Transform parent, string text, int size, Color color, bool outline = true)
        {
            GameObject obj = new GameObject("TMP_Text");
            obj.transform.SetParent(parent, false);

            var t = obj.AddComponent<TextMeshProUGUI>();
            t.text = text;
            t.fontSize = size;
            t.color = color;
            t.alignment = TextAlignmentOptions.MidlineLeft;

            //if (defaultFont != null)
            //    t.font = defaultFont;

            t.enableAutoSizing = true;
            t.fontSizeMin = size - 4;
            t.fontSizeMax = size + 6;

            // Outline
            if (outline)
            {
                t.outlineWidth = 0.2f;
                t.outlineColor = Color.black;
            }

            return t;
        }

        protected Button CreateButton(Transform parent, string label, System.Action onClick)
        {
            GameObject btnObj = new GameObject(label);
            btnObj.transform.SetParent(parent, false);

            Image img = btnObj.AddComponent<Image>();
            img.color = new Color(0.2f, 0.2f, 0.2f);

            Button btn = btnObj.AddComponent<Button>();
            btn.onClick.AddListener(() => onClick?.Invoke());

            var txt = CreateText(btnObj.transform, label, 14, Color.white);
            txt.alignment = TextAlignmentOptions.Center;

            Stretch(txt.rectTransform);

            btn.onClick.AddListener(() => AnimatePulse(btnObj));

            return btn;
        }

        protected VerticalLayoutGroup AddVerticalLayout(GameObject obj, int spacing = 5)
        {
            var layout = obj.AddComponent<VerticalLayoutGroup>();
            layout.spacing = spacing;
            layout.childAlignment = TextAnchor.UpperCenter;
            layout.padding = new RectOffset(10, 10, 10, 10);
            return layout;
        }

        protected HorizontalLayoutGroup AddHorizontalLayout(GameObject obj, int spacing = 5)
        {
            var layout = obj.AddComponent<HorizontalLayoutGroup>();
            layout.spacing = spacing;
            return layout;
        }

        protected void FadeIn(CanvasGroup cg, float duration = 0.2f)
        {

            StartCoroutine(Fade(cg, 0, 1, duration));
        }

        protected void FadeOut(CanvasGroup cg, float duration = 0.2f)
        {
            StartCoroutine(Fade(cg, 1, 0, duration));
        }

        IEnumerator Fade(CanvasGroup cg, float a, float b, float t)
        {
            float time = 0;
            while (time < t)
            {
                time += Time.unscaledDeltaTime;
                cg.alpha = Mathf.Lerp(a, b, time / t);
                yield return null;
            }
            cg.alpha = b;
        }

        protected void AnimatePulse(GameObject obj)
        {
            StartCoroutine(Pulse(obj));
        }

        IEnumerator Pulse(GameObject obj)
        {
            Vector3 original = obj.transform.localScale;
            Vector3 target = original * 1.1f;

            float t = 0;
            while (t < 0.1f)
            {
                t += Time.unscaledDeltaTime;
                obj.transform.localScale = Vector3.Lerp(original, target, t / 0.1f);
                yield return null;
            }

            t = 0;
            while (t < 0.1f)
            {
                t += Time.unscaledDeltaTime;
                obj.transform.localScale = Vector3.Lerp(target, original, t / 0.1f);
                yield return null;
            }
        }

        protected void Stretch(RectTransform rect)
        {
            rect.anchorMin = Vector2.zero;
            rect.anchorMax = Vector2.one;
            rect.offsetMin = Vector2.zero;
            rect.offsetMax = Vector2.zero;
        }

        protected bool IsVREnabled()
        {
            return XRSettings.isDeviceActive && XRSettings.enabled || FakeVr;
        }

        private void HandleVRFollow(GameObject canvas)
        {
            Transform cam = Camera.main != null ? Camera.main.transform : transform;

            Vector3 targetPos =
                cam.position +
                (cam.forward * vrDistance) +
                (cam.right * vrHorizontalOffset) +
                (cam.up * vrVerticalOffset);

            canvas.transform.position = Vector3.Lerp(
                canvas.transform.position,
                targetPos,
                Time.unscaledDeltaTime * smoothSpeed
            );

            canvas.transform.LookAt(canvas.transform.position + cam.forward);
        }

        void EnsureEventSystem()
        {
            if (FindObjectOfType<EventSystem>() == null)
            {
                GameObject es = new("EventSystem");
                es.AddComponent<EventSystem>();
                es.AddComponent<StandaloneInputModule>();
            }
        }
    }
}
