﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using TMPro;
using UnityEngine;
using UnityEngine.Profiling;
using UnityEngine.UI;

namespace KittyRec.UI
{
    internal class PerformanceUi : KR_UiBase
    {
        private GameObject panel;
        private RawImage graphImage;
        private Texture2D graphTex;

        private TextMeshProUGUI fpsText, frameText, memoryText, objectText, rendererText, gcText;

        private Dictionary<int, Button> qualityButtons = new Dictionary<int, Button>();

        // Data tracking
        private Queue<float> frameHistory = new Queue<float>();
        private float deltaTime;
        private float nextUpdate;
        private long cachedObjectCount;
        private int lastGC;
        private int rendererCount;
        private int triangleCount;
        private readonly object lockObj = new object();

        // Graph
        private const int graphWidth = 200;
        private const int graphHeight = 60;

        protected override void Awake()
        {
            base.Awake();
            CreateOverlayUI();
#if DEBUG
            panel.SetActive(true);
#else
            panel.SetActive(false);
#endif
        }

        private void CreateOverlayUI()
        {
            panel = CreatePanel(canvasObj.transform, new Vector2(260, 380), new Color(0, 0, 0, 0.75f));
            AddVerticalLayout(panel);

            CreateText(panel.transform, "Performance (F8)", 18, Color.white);
            fpsText = CreateText(panel.transform, "", 14, Color.green);
            frameText = CreateText(panel.transform, "", 14, Color.green);

            CreateGraph();

            memoryText = CreateText(panel.transform, "", 14, Color.green);
            objectText = CreateText(panel.transform, "", 14, Color.green);
            rendererText = CreateText(panel.transform, "", 14, Color.green);
            gcText = CreateText(panel.transform, "", 14, Color.green);

            CreateQualityButtons();
        }

        private void CreateGraph()
        {
            GameObject graph = new GameObject("FPSGraph");
            graph.transform.SetParent(panel.transform, false);
            graphImage = graph.AddComponent<RawImage>();
            graphTex = new Texture2D(graphWidth, graphHeight, TextureFormat.RGBA32, false);
            graphImage.texture = graphTex;
            graphImage.rectTransform.sizeDelta = new Vector2(graphWidth, graphHeight);
        }

        private void CreateQualityButtons()
        {
            GameObject row = new GameObject("QualityButtons");
            row.transform.SetParent(panel.transform, false);
            AddHorizontalLayout(row);

            CreateQualityButton(row.transform, "Fast", 0);
            CreateQualityButton(row.transform, "Simple", 1);
            CreateQualityButton(row.transform, "Beauty", 2);
            CreateQualityButton(row.transform, "Fant", 3);
        }

        private void CreateQualityButton(Transform parent, string label, int level)
        {
            Button btn = CreateButton(parent, label, () => SetQualityLevel((PGFOBJCJHJK)level));
            qualityButtons[level] = btn;
        }

        private void SetQualityLevel(PGFOBJCJHJK level)
        {
            try
            {
                SingletonMonoBehaviour<SettingsManager>.OJAGNDKABPJ.FDCHOEHMJGN = level;
            }
            catch { }
        }

        private void Update()
        {
            deltaTime += (Time.unscaledDeltaTime - deltaTime) * 0.1f;

            if (Input.GetKeyDown(KeyCode.F8))
                panel.SetActive(!panel.activeSelf);

            if (!panel.activeSelf) return;

            if (Input.GetKey(KeyCode.LeftAlt))
            {
                if (Input.GetKeyDown(KeyCode.Alpha1)) SetQualityLevel(PGFOBJCJHJK.Fastest);
                else if (Input.GetKeyDown(KeyCode.Alpha2)) SetQualityLevel(PGFOBJCJHJK.Simple);
                else if (Input.GetKeyDown(KeyCode.Alpha3)) SetQualityLevel(PGFOBJCJHJK.Beautiful);
                else if (Input.GetKeyDown(KeyCode.Alpha4)) SetQualityLevel(PGFOBJCJHJK.Fantastic);
            }

            if (Time.time >= nextUpdate)
            {
                cachedObjectCount = Resources.FindObjectsOfTypeAll(typeof(GameObject)).Length;
                Renderer[] snapshot = Resources.FindObjectsOfTypeAll<Renderer>();
                Thread t = new Thread(() => CalculateRenderersAsync(snapshot));
                t.IsBackground = true;
                t.Start();
                nextUpdate = Time.time + 1f;
            }

            UpdateStats();
            UpdateGraph();
            UpdateQualityHighlight();
        }

        private void CalculateRenderersAsync(Renderer[] renderers)
        {
            int rCount = renderers.Length;
            int tCount = 0;
            foreach (Renderer r in renderers)
            {
                if (r is MeshRenderer || r is SkinnedMeshRenderer)
                {
                    MeshFilter mf = r.GetComponent<MeshFilter>();
                    if (mf && mf.sharedMesh != null)
                        tCount += mf.sharedMesh.triangles.Length / 3;
                }
            }
            lock (lockObj) { rendererCount = rCount; triangleCount = tCount; }
        }

        private void UpdateStats()
        {
            float fps = 1f / deltaTime;
            float ms = deltaTime * 1000f;
            fpsText.text = $"FPS: {fps:0}";
            fpsText.color = GetFPSColor(fps);
            frameText.text = $"Frame: {ms:0.0} ms";

            memoryText.text = $"Memory: {Profiler.GetTotalAllocatedMemoryLong() / 1048576f:0} MB";
            objectText.text = $"Objects: {cachedObjectCount}";

            int r, t;
            lock (lockObj) { r = rendererCount; t = triangleCount; }
            rendererText.text = $"Renderers: {r} | Tris: {t / 1000}k";

            int gc = System.GC.CollectionCount(0);
            gcText.text = $"GC Gen0: {gc}";
            gcText.color = gc > lastGC ? Color.yellow : Color.green;
            lastGC = gc;
        }

        private void UpdateGraph()
        {
            float fps = 1f / deltaTime;
            frameHistory.Enqueue(fps);
            if (frameHistory.Count > graphWidth) frameHistory.Dequeue();

            Color clear = new Color(0, 0, 0, 0);
            for (int x = 0; x < graphWidth; x++)
                for (int y = 0; y < graphHeight; y++)
                    graphTex.SetPixel(x, y, clear);

            int i = 0;
            foreach (float f in frameHistory)
            {
                int h = Mathf.Clamp((int)(f / 120f * graphHeight), 0, graphHeight - 1);
                Color c = GetFPSColor(f);
                for (int y = 0; y < h; y++)
                    graphTex.SetPixel(i, y, c);
                i++;
            }
            graphTex.Apply();
        }

        private Color GetFPSColor(float fps)
        {
            if (fps < 30) return Color.red;
            if (fps < 60) return Color.yellow;
            return Color.green;
        }

        private void UpdateQualityHighlight()
        {
            try
            {
                int current = (int)SingletonMonoBehaviour<SettingsManager>.OJAGNDKABPJ.FDCHOEHMJGN;
                foreach (var kv in qualityButtons)
                    kv.Value.GetComponent<Image>().color = kv.Key == current ? Color.green : Color.gray;
            }
            catch
            {
                foreach (var kv in qualityButtons)
                    kv.Value.GetComponent<Image>().color = Color.red;
            }
        }
    }
}
